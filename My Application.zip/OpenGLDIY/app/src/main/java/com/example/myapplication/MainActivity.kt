package com.example.myapplication

import android.opengl.GLSurfaceView
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil

import android.renderscript.ScriptGroup

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var glSurfaceView :GLSurfaceView? = findViewById(R.id.glSurfaceView)
        glSurfaceView.setEGLContextClientVersion(3)
        var binding =
    }

    override fun onResume() {
        super.onResume()

    }
}